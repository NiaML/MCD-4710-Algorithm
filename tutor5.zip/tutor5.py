# task 2 Deep copy
# Copying lists with depth exactly 2
def deepcopy_depth(lst):
    copylist = []
    for index_1 in range(len(lst)):
        copylist.append (None)
    for index_1 in range(len(lst)):
        for index_2 in range(len(lst[index_1])):
            copylist [index_1].append(lst[index_1][index_2])
    return copylist


# Copying lists with depth at-most 2
def deepcopy_depth(lst):
    copylist = []
    for index_1 in range(len(lst)):
        copylist.append (None)
    for index_1 in range(len(lst)):
        if isinstance(lst[index_1], list): 
            copylist[index_1] = []
            for index_2 in range(len(lst[index_1])): 
                copylist[index_1].append(lst[index_1][index_2])
            else:
                copylist[index_1] = lst[index_1] 
    return copylist

# task 3 Decomposition
def string_to_int(lst):
    for index in range(lst): 
        lst[index] = int(lst[index])
    return lst

def square_list(lst):
    for index in range(len(lst)): 
        lst[index] = lst[index]**2
    return lst

def diff_in_list(lst,number): 
    list_temp = []
    for item in lst: 
        list_temp.append(item - number)
    return list_temp

def sum(lst):
    sum_temp =0
    for obj in lst:
        sum_temp = sum_temp + obj 
    return sum_temp

def average(lst):
    return sum(lst)/len(lst)

def variance(lst):
    lst = string_to_int(lst) 
    average_temp = average(lst)
    diff_temp = diff_in_list(lst,average_temp) 
    square_list_temp = square_list(diff_temp) 
    return sum(square_list_temp)